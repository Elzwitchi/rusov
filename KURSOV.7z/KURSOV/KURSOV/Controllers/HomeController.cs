﻿using KURSOV.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace KURSOV.Controllers
{
    public class HomeController : Controller
    {
        private readonly UserContext db;
        public HomeController(UserContext context)
        {
            db = context;
        }

        [Authorize]
        public IActionResult Index()
        {
            return View(db.Students);
        }

        public IActionResult Create()
        {
            return View();
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id != null)
            {
                Student student = await db.Students.FirstOrDefaultAsync(p => p.Id == id);
                if (student != null)
                {
                    try
                    {
                        db.Students.Remove(student);
                        await db.SaveChangesAsync();
                        return RedirectToAction("Index");
                    }
                    catch
                    {
                        ViewBag.Error = "Ошибка!";
                        return RedirectToAction("Index");
                    }
                }
            }
            ViewBag.Error = "Ошибка!";
            return RedirectToAction("Index");
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Add(Student student)
        {
            try
            {
                db.Students.Add(student);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch
            {
                ViewBag.Error = "Стуент не добавился";
                return RedirectToAction("Create");
            }
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Editing(int? id)
        {
            try
            {
                if (id == null) return RedirectToAction("Index");
                var student = await db.Students.FirstOrDefaultAsync(p => p.Id == id);
                ViewBag.Student = student;
                ViewBag.StudentId = id;
                return View();
            }
            catch
            {
                return RedirectToAction("Index");
            }
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> Editing(Student student)
        {
            try
            {
                db.Students.Update(student);
                await db.SaveChangesAsync();
                return RedirectToAction("Index");
            }
            catch
            {
                ViewBag.Error = "Ошибка";
                return View();
            }
        }
    }
}
