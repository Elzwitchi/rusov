﻿using KURSOV.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KURSOV
{
    public class SampleData
    {
        public static void Initialize(UserContext context)
        {
            if (!context.Users.Any())
            {
                context.Users.AddRange(
                    new User
                    {
                        Email = "Admin",
                        Password = "admin1234"
                    });
                context.SaveChanges();
            }
        }
    }
}
